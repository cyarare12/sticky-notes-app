from django.shortcuts import render, get_object_or_404, redirect
from .models import Note
from .forms import NoteForm

def note_list(request):
    """
    Display a list of all notes ordered by creation date (newest first).

    Args:
        request: The HTTP request object.

    Returns:
        HttpResponse: Rendered template with list of notes.
    """
    notes = Note.objects.all().order_by('-created_at')
    return render(request, 'notes/note_list.html', {'notes': notes})

def note_create(request):
    """
    Handle creation of a new note.

    If the request is POST and the form is valid, save the note and redirect to the list.
    Otherwise, display the form for creating a new note.

    Args:
        request: The HTTP request object.

    Returns:
        HttpResponse: Redirect to note list on success, or rendered form template.
    """
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = NoteForm()
    return render(request, 'notes/note_form.html', {'form': form})

def note_update(request, pk):
    """
    Handle updating an existing note.

    Retrieve the note by primary key. If the request is POST and the form is valid,
    save the changes and redirect to the list. Otherwise, display the form with current data.

    Args:
        request: The HTTP request object.
        pk (int): Primary key of the note to update.

    Returns:
        HttpResponse: Redirect to note list on success, or rendered form template.
    """
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = NoteForm(instance=note)
    return render(request, 'notes/note_form.html', {'form': form})

def note_delete(request, pk):
    """
    Handle deletion of an existing note.

    Display a confirmation page for deletion. If the request is POST, delete the note
    and redirect to the list.

    Args:
        request: The HTTP request object.
        pk (int): Primary key of the note to delete.

    Returns:
        HttpResponse: Redirect to note list on deletion, or rendered confirmation template.
    """
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        note.delete()
        return redirect('note_list')
    return render(request, 'notes/note_confirm_delete.html', {'note': note})
