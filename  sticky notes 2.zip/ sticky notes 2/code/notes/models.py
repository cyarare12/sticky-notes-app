from django.db import models

class Note(models.Model):
    """
    Model representing a sticky note.

    Attributes:
        title (CharField): The title of the note, max length 200 characters.
        content (TextField): The content of the note.
        created_at (DateTimeField): Timestamp when the note was created, auto-set on creation.
        updated_at (DateTimeField): Timestamp when the note was last updated, auto-updated on save.
    """
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        """
        Return the string representation of the note, which is its title.
        """
        return self.title
