from django import forms
from .models import Note

class NoteForm(forms.ModelForm):
    """
    Form for creating and updating Note instances.

    This form includes fields for title and content of a note.
    """
    class Meta:
        model = Note
        fields = ['title', 'content']