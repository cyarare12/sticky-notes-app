from django.test import TestCase
from django.urls import reverse
from .models import Note
from .forms import NoteForm

class NoteModelTest(TestCase):
    """
    Test cases for the Note model.
    """
    def setUp(self):
        """
        Set up test data for Note model tests.
        """
        self.note = Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_creation(self):
        """
        Test that a Note instance is created with correct attributes.
        """
        self.assertEqual(self.note.title, 'Test Note')
        self.assertEqual(self.note.content, 'This is a test note.')
        self.assertIsNotNone(self.note.created_at)
        self.assertIsNotNone(self.note.updated_at)

    def test_note_str(self):
        """
        Test the string representation of a Note.
        """
        self.assertEqual(str(self.note), 'Test Note')

class NoteFormTest(TestCase):
    """
    Test cases for the NoteForm.
    """
    def test_valid_form(self):
        """
        Test that the form is valid with correct data.
        """
        data = {'title': 'New Note', 'content': 'New content'}
        form = NoteForm(data=data)
        self.assertTrue(form.is_valid())

    def test_invalid_form(self):
        """
        Test that the form is invalid with missing required fields.
        """
        data = {'title': '', 'content': 'Content without title'}
        form = NoteForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('title', form.errors)

class NoteViewTest(TestCase):
    """
    Test cases for Note views.
    """
    def setUp(self):
        """
        Set up test data for view tests.
        """
        self.note = Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_list_view(self):
        """
        Test the note list view displays notes correctly.
        """
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')
        self.assertTemplateUsed(response, 'notes/note_list.html')

    def test_note_create_view_get(self):
        """
        Test GET request to note create view.
        """
        response = self.client.get(reverse('note_create'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')

    def test_note_create_view_post_valid(self):
        """
        Test POST request to create a note with valid data.
        """
        data = {'title': 'New Note', 'content': 'New content'}
        response = self.client.post(reverse('note_create'), data)
        self.assertEqual(response.status_code, 302)  # Redirect to list
        self.assertEqual(Note.objects.count(), 2)
        self.assertRedirects(response, reverse('note_list'))

    def test_note_create_view_post_invalid(self):
        """
        Test POST request to create a note with invalid data.
        """
        data = {'title': '', 'content': 'Content'}
        response = self.client.post(reverse('note_create'), data)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')
        self.assertEqual(Note.objects.count(), 1)  # No new note created

    def test_note_update_view_get(self):
        """
        Test GET request to note update view.
        """
        response = self.client.get(reverse('note_update', args=[self.note.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')

    def test_note_update_view_post_valid(self):
        """
        Test POST request to update a note with valid data.
        """
        data = {'title': 'Updated Note', 'content': 'Updated content'}
        response = self.client.post(reverse('note_update', args=[self.note.pk]), data)
        self.assertEqual(response.status_code, 302)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Note')
        self.assertRedirects(response, reverse('note_list'))

    def test_note_update_view_post_invalid(self):
        """
        Test POST request to update a note with invalid data.
        """
        data = {'title': '', 'content': 'Updated content'}
        response = self.client.post(reverse('note_update', args=[self.note.pk]), data)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Test Note')  # Unchanged

    def test_note_delete_view_get(self):
        """
        Test GET request to note delete confirmation view.
        """
        response = self.client.get(reverse('note_delete', args=[self.note.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_confirm_delete.html')

    def test_note_delete_view_post(self):
        """
        Test POST request to delete a note.
        """
        response = self.client.post(reverse('note_delete', args=[self.note.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Note.objects.count(), 0)
        self.assertRedirects(response, reverse('note_list'))
